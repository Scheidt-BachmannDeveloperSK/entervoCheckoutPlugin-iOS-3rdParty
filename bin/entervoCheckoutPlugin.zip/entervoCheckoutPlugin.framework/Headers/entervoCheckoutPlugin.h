//
//  entervoCheckoutPlugin.h
//  entervoCheckoutPlugin
//
//  Created by Developer on 16.12.17.
//  Copyright © 2017 Scheidt & Bachmann. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for entervoCheckoutPlugin.
FOUNDATION_EXPORT double entervoCheckoutPluginVersionNumber;

//! Project version string for entervoCheckoutPlugin.
FOUNDATION_EXPORT const unsigned char entervoCheckoutPluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <entervoCheckoutPlugin/PublicHeader.h>


